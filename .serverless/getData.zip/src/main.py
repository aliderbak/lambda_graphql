import graphene
from app.core.repository.dbhandler import DBHandler
from app.messages.api_response import GraphQLQueryBadRequest, GraphQLQueryResponseSuccess
from app.graphql.mutation import Mutation
from app.graphql.query import Query
def graphql(event, context):
# Initialize Schema
    schema = graphene.Schema(query=Query, mutation=Mutation, types=query.types + mutation.types)
    # Execute Schema
    with DBHandler().session_scope() as session:
        try:
            result = schema.execute(event.action, context={'session': session})
            return GraphQLQueryResponseSuccess(result.to_dict())
        except Exception as e:
            return GraphQLQueryBadRequest(result.to_dict())